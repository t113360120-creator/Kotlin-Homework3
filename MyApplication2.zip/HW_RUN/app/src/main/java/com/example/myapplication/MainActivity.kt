package com.example.myapplication // 請保留你專案原本第 1 行的 package 名稱

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    // 建立兩個數值，用於計算兔子與烏龜的進度
    private var progressRabbit = 0
    private var progressTurtle = 0

    private lateinit var btnStart: Button
    private lateinit var sbRabbit: SeekBar
    private lateinit var sbTurtle: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStart = findViewById(R.id.btnStart)
        sbRabbit = findViewById(R.id.sbRabbit)
        sbTurtle = findViewById(R.id.sbTurtle)

        btnStart.setOnClickListener {
            btnStart.isEnabled = false // 比賽期間，不可重複操作
            progressRabbit = 0         // 初始化進度
            progressTurtle = 0
            sbRabbit.progress = 0
            sbTurtle.progress = 0

            // 執行賽跑協程
            runRabbit()
            runTurtle()
        }
    }

    private fun runRabbit() {
        lifecycleScope.launch {
            // 兔子有三分之二的機率會偷懶
            val sleepProbability = arrayOf(true, true, false)

            while (progressRabbit <= 100 && progressTurtle < 100) {
                delay(100) // 延遲 0.1 秒
                // 隨機 0 ~ 2：0 和 1 為兔子休息、2 為移動
                if (sleepProbability[(Math.random() * 3).toInt()]) {
                    delay(300) // 兔子休息 0.3 秒
                }
                progressRabbit += 3 // 每次三步
                sbRabbit.progress = progressRabbit // 直接更新進度條

                // 判斷兔子是否獲勝
                if (progressRabbit >= 100 && progressTurtle < 100) {
                    Toast.makeText(this@MainActivity, "兔子勝", Toast.LENGTH_SHORT).show()
                    btnStart.isEnabled = true
                }
            }
        }
    }

    private fun runTurtle() {
        lifecycleScope.launch {
            while (progressTurtle <= 100 && progressRabbit < 100) {
                delay(100) // 延遲 0.1 秒
                progressTurtle += 1 // 每次一步
                sbTurtle.progress = progressTurtle // 直接更新進度條

                // 判斷烏龜是否獲勝
                if (progressTurtle >= 100 && progressRabbit < 100) {
                    Toast.makeText(this@MainActivity, "烏龜勝", Toast.LENGTH_SHORT).show()
                    btnStart.isEnabled = true
                }
            }
        }
    }
}